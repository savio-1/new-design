# Cogentiq — Model hub · developer handoff

Generated 2026-09-07 from the working prototype.

## What is in here

| File | What it is |
|---|---|
| `model-hub.html` | The page, working. One file, no build step, no dependencies — open it in a browser. This is the behavioural source of truth: where this document and the page disagree, the page is right. |
| `design-system.html` | The component reference. Every token with both theme values, every component live, and the rules behind them. Open the **Tagging** section for the three surfaces this handoff is about. |
| `page-guidelines.html` | The frame every module shares — shell, spacing, the panel, where things go. |
| `cogentiq-design-system.css` | The library. This is the file you link. Token names match the Figma variables one-for-one. |
| `HANDOFF.md` | The spec: page structure, the tagging feature in full, what is real and what is mocked. |
| `tagging/tagging.css` | The tagging CSS, lifted out of the library so you can read it in one place. Ship the library, not this. |
| `tagging/tagging.js` | The tagging behaviour, lifted out of the page. Vanilla, 322 lines, no dependencies. |
| `tagging/tagging.html` | The markup skeletons for the menu, the picker and the two-pane filter. |

## Getting started

    <link rel="stylesheet" href="cogentiq-design-system.css">
    <html data-mode="light">        <!-- omit for dark, the product default -->
      <body class="cq"> … </body>

Dark is the default. Every component is written against tokens only, so
both themes come free — never hard-code a colour in a screen. If a value
is missing, add a token to the library rather than a literal to the
page.

## Reading order

1. `design-system.html` → **Tagging**. Play with all three surfaces;
   they share one list, so a rename in the manage pane changes the card
   and the filter as you watch.
2. `HANDOFF.md` → the spec, including every state and edge case.
3. `model-hub.html` → the real thing, in context.

## One thing to fix before you ship

The destructive colour family (`--text-coloured-red`,
`--backgrounds-button-danger`, `--backgrounds-badge-red`,
`--strokes-colour-red`) is **derived**, not read from Figma. The library
has `Text/Coloured- red` and `Strokes/Colour/Red` published but neither
returned a value, so these follow Figma's brand red through the same
construction the other five colour families use. Replace the four pairs
in `cogentiq-design-system.css` once someone can read the real values —
nothing outside the delete affordances depends on them.
