/* Tagging — the reference implementation, lifted verbatim from
   model-hub.html. Vanilla, no dependencies, no build step. The
   store it talks to (MODELS, TAG_FILTERS, state.tags) is the
   prototype's; swap those three for your own and the surfaces
   behave the same. */

/* ══ Tagging ══════════════════════════════════════════════════════
   A card's 3-dot menu, the picker it opens, and the manage pane in
   the tags filter. All three read and write one tag vocabulary, so a
   rename in the manage pane reaches the cards, the panel and the
   filter at once.

   The menu and the picker are position:fixed and placed from the
   button's rect. Anchoring them inside a card would work until the
   grid scrolled, and then the surface would ride away from the
   button that opened it.                                        ── */
let menuFor = null;      /* model index the card menu belongs to */
let pickerFor = null;    /* model index the picker is editing    */
let pickerQuery = '';

function placeSurface(el, anchor, w) {
  const r = anchor.getBoundingClientRect();
  const width = w || el.offsetWidth || 200;
  const left = Math.max(12, Math.min(r.right - width, window.innerWidth - width - 12));
  el.style.left = left + 'px';
  /* Flip above the button when there is not room below it. */
  const below = window.innerHeight - r.bottom;
  const h = el.offsetHeight || 200;
  el.style.top = (below > h + 16 ? r.bottom + 6 : Math.max(12, r.top - h - 6)) + 'px';
}

function closeTagSurfaces() {
  $('cardMenu').classList.remove('is-open');
  $('tagPicker').classList.remove('is-open');
  menuFor = pickerFor = null;
  pickerQuery = '';
}

function openCardMenu(i, anchor) {
  closeTagSurfaces();
  menuFor = i;
  const el = $('cardMenu');
  el.classList.add('is-open');
  placeSurface(el, anchor, 200);
}

function openTagPicker(i, anchor) {
  const wasFor = pickerFor;
  closeTagSurfaces();
  if (wasFor === i) return;
  pickerFor = i;
  $('tagPicker').classList.add('is-open');
  renderPicker();
  placeSurface($('tagPicker'), anchor, 288);
  $('pickerInput').focus();
}

function renderPicker() {
  if (pickerFor === null) return;
  const m = MODELS[pickerFor];
  const q = pickerQuery.trim(), lower = q.toLowerCase();
  const matches = allTags().filter(t => t.toLowerCase().includes(lower));
  const exact = allTags().some(t => t.toLowerCase() === lower);

  $('tagPicker').innerHTML = `
    <div class="tag-field" id="pickerField">
      ${m.tags.map(t => `
        <span class="tag tag--removable is-tinted" data-tone="${tone(t)}">${esc(t)}
          <button class="tag-x" data-untag="${esc(t)}" aria-label="Remove ${esc(t)}">
            <svg viewBox="0 0 20 20"><use href="#ic-close"/></svg></button></span>`).join('')}
      <input id="pickerInput" class="t-body2-reg" value="${esc(q)}"
             placeholder="${m.tags.length ? 'Add another' : 'Add a tag'}"
             aria-label="Search or create a tag" />
    </div>
    ${q && !exact ? `
      <button class="tag-create t-body2-reg" data-create="${esc(q)}">
        <svg class="ic" viewBox="0 0 20 20"><use href="#ic-plus"/></svg>Create <b>${esc(q)}</b></button>` : ''}
    <div class="tag-pop-list">
      ${matches.length ? matches.map(t => `
        <button class="tag-opt t-body2-reg${m.tags.includes(t) ? ' is-checked' : ''}" data-toggle="${esc(t)}">
          <span class="box"><svg viewBox="0 0 12 12"><use href="#ic-tick"/></svg></span>
          <span style="flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis">${esc(t)}</span>
        </button>`).join('')
        : `<div class="tag-pop-empty t-caption1-reg">No tag matches “${esc(q)}”.</div>`}
    </div>`;

  const input = $('pickerInput');
  input.addEventListener('input', e => {
    pickerQuery = e.target.value;
    renderPicker();
    $('pickerInput').focus();
  });
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && pickerQuery.trim()) { e.preventDefault(); createTagOnModel(pickerQuery.trim()); }
    else if (e.key === 'Backspace' && !pickerQuery && m.tags.length) { m.tags.pop(); afterTagChange(); }
    else if (e.key === 'Escape') { e.preventDefault(); closeTagSurfaces(); }
  });
  const caret = input.value.length;
  input.setSelectionRange(caret, caret);
}

function createTagOnModel(name) {
  const m = MODELS[pickerFor];
  if (!allTags().some(t => t.toLowerCase() === name.toLowerCase())) TAG_FILTERS.push(name);
  if (!m.tags.includes(name)) m.tags.push(name);
  pickerQuery = '';
  afterTagChange();
  $('pickerInput').focus();
}

/* One repaint for every surface that shows a tag. */
function afterTagChange() {
  renderCards();
  renderTagPop();
  renderNewTagRow();
  if (pickerFor !== null) renderPicker();
  if (state.selected !== null) renderPanelTags();
}

$('tagPicker').addEventListener('click', e => {
  e.stopPropagation();
  if (pickerFor === null) return;
  const m = MODELS[pickerFor];
  const un = e.target.closest('[data-untag]');
  if (un) { m.tags = m.tags.filter(t => t !== un.dataset.untag); return afterTagChange(); }
  const cr = e.target.closest('[data-create]');
  if (cr) return createTagOnModel(cr.dataset.create);
  const tg = e.target.closest('[data-toggle]');
  if (tg) {
    const t = tg.dataset.toggle;
    m.tags.includes(t) ? m.tags = m.tags.filter(x => x !== t) : m.tags.push(t);
    return afterTagChange();
  }
  $('pickerInput') && $('pickerInput').focus();
});

$('cardMenu').addEventListener('click', e => {
  e.stopPropagation();
  const item = e.target.closest('[data-act]');
  if (item === null || menuFor === null) return;
  const i = menuFor;
  const anchor = document.querySelector(`[data-card-menu="${i}"]`);
  if (item.dataset.act === 'edit') { closeTagSurfaces(); openModal(i); }
  if (item.dataset.act === 'tags') openTagPicker(i, anchor);
  if (item.dataset.act === 'delete') { closeTagSurfaces(); deleteModel(i); }
});

/* ── The manage pane inside the tags filter ─────────────────────── */
let tagPane = 'filter';
let renaming = null, confirming = null, renameError = '';
let addingTag = false, newTagError = '';

/* The row + Tag opens. It creates the tag in the vocabulary only — it
   does not put it on anything. Tagging a record is what the picker on
   the card is for; this is the list of tags the platform has. */
function renderNewTagRow() {
  $('newTagSlot').innerHTML = addingTag ? `
    <div class="tag-new">
      <label class="search-field">
        <input id="newTagInput" class="t-body2-reg" placeholder="Name the new tag"
               aria-label="Name the new tag" /></label>
      <button class="btn-primary t-body2-med" id="newTagAdd">Add</button>
    </div>
    ${newTagError ? `<div class="inline-error t-caption1-reg">${esc(newTagError)}</div>` : ''}` : '';
  $('newTagBtn').setAttribute('aria-expanded', String(addingTag));
  if (addingTag && $('newTagInput')) $('newTagInput').focus();
}

function commitNewTag(name) {
  name = (name || '').trim();
  if (!name) { addingTag = false; newTagError = ''; return renderNewTagRow(); }
  if (allTags().some(t => t.toLowerCase() === name.toLowerCase())) {
    newTagError = `“${name}” already exists.`;
    return renderNewTagRow();
  }
  TAG_FILTERS.push(name);
  addingTag = false; newTagError = '';
  afterTagChange();
}

function renameTag(from, to) {
  to = to.trim();
  if (!to || to === from) { renaming = null; renameError = ''; return renderTagPop(); }
  if (allTags().some(t => t.toLowerCase() === to.toLowerCase())) {
    renameError = `“${to}” already exists. Pick another name.`;
    return renderTagPop();
  }
  /* One pass over everything that can name a tag. Miss any of these and
     the page ends up holding two names for one thing. */
  TAG_FILTERS = TAG_FILTERS.map(t => t === from ? to : t);
  MODELS.forEach(m => { m.tags = m.tags.map(t => t === from ? to : t); });
  if (TAG_TONE[from]) { TAG_TONE[to] = TAG_TONE[from]; delete TAG_TONE[from]; }
  if (state.tags.delete(from)) state.tags.add(to);
  renaming = null; renameError = '';
  afterTagChange();
}

function deleteTag(t) {
  TAG_FILTERS = TAG_FILTERS.filter(x => x !== t);
  MODELS.forEach(m => { m.tags = m.tags.filter(x => x !== t); });
  delete TAG_TONE[t];
  state.tags.delete(t);
  confirming = null;
  afterTagChange();
}

function renderPanelTags() {
  const m = MODELS[state.selected];
  if (!m || !$('panelTags')) return;
  $('panelTags').innerHTML = m.tags.map(t =>
    `<span class="tag-badge" data-tone="${tone(t)}">${esc(t)}</span>`).join('');
}

function renderTagPop() {
  const q = $('tagSearch') ? $('tagSearch').value.trim().toLowerCase() : '';
  const rows = allTags();

  $('tagPopList').innerHTML = rows
    .filter(t => t.toLowerCase().includes(q))
    .map(t => `
      <button class="tag-opt t-body2-reg${state.tags.has(t) ? ' is-checked' : ''}" data-tag="${esc(t)}">
        <span class="box"><svg viewBox="0 0 12 12"><use href="#ic-tick"/></svg></span>
        <span style="flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis">${esc(t)}</span>
      </button>`).join('');

  $('tagManageList').innerHTML = rows.map(t => tagManageRow(t)).join('');
  $('tagManageError').innerHTML = renameError
    ? `<div class="inline-error t-caption1-reg">${esc(renameError)}</div>` : '';

  $('tagFilterPane').classList.toggle('is-active', tagPane === 'filter');
  $('tagManagePane').classList.toggle('is-active', tagPane === 'manage');

  const n = state.tags.size;
  $('tagsCount').textContent = n;
  $('tagsDropdown').classList.toggle('has-count', n > 0);

  const ren = $('tagManageList').querySelector('.tag-manage-edit input');
  if (ren) { ren.focus(); ren.select(); }
}

function tagManageRow(t) {
  const st = renaming === t ? ' is-renaming' : confirming === t ? ' is-confirming' : '';
  return `
    <div class="tag-manage${st}" data-row="${esc(t)}">
      <span class="tag-manage-label t-body2-reg">${esc(t)}</span>
      <span class="tag-manage-actions">
        <button class="icon-btn-24" data-rename="${esc(t)}" aria-label="Rename ${esc(t)}">
          <svg class="ic" width="16" height="16" viewBox="0 0 20 20"><use href="#ic-rowedit"/></svg></button>
        <button class="icon-btn-24 tag-manage-del" data-ask-del="${esc(t)}" aria-label="Delete ${esc(t)}">
          <svg class="ic" width="16" height="16" viewBox="0 0 20 20"><use href="#ic-rowdelete"/></svg></button>
      </span>
      <label class="search-field tag-manage-edit">
        <input class="t-body2-reg" value="${esc(t)}" aria-label="New name for ${esc(t)}" /></label>
      <span class="tag-manage-confirm">
        <span class="t-body2-reg">Delete “${esc(t)}”? It comes off everything across the platform that carries it.</span>
        <span class="tag-manage-confirm-actions">
          <button class="btn-quiet t-caption1-reg" data-cancel-del="1">Cancel</button>
          <button class="btn-danger t-caption1-reg" data-do-del="${esc(t)}">Delete</button>
        </span>
      </span>
    </div>`;
}

/* People are whoever actually authored a model, so a model you create
   adds you to the list without a separate roster to maintain. */

/* ── The handlers ─────────────────────────────────────────────── */
$('cardArea').addEventListener('click', e => {
  const dots = e.target.closest('[data-card-menu]');
  if (dots) {
    e.stopPropagation();
    const i = Number(dots.dataset.cardMenu);
    return menuFor === i ? closeTagSurfaces() : openCardMenu(i, dots);
  }
  const c = e.target.closest('.card');
  if (!c) return;
  const i = Number(c.dataset.index);
  if (state.selected === i) closePanel(); else openPanel(i);
});

/* The 3-dot lives inside a <button>, so it cannot be one itself. Enter
   and Space have to be wired by hand for it to be reachable at all. */
$('cardArea').addEventListener('keydown', e => {
  const dots = e.target.closest('[data-card-menu]');
  if (!dots || (e.key !== 'Enter' && e.key !== ' ')) return;
  e.preventDefault(); e.stopPropagation();
  const i = Number(dots.dataset.cardMenu);
  menuFor === i ? closeTagSurfaces() : openCardMenu(i, dots);
});

$('tagPop').addEventListener('click', e => {
  if (e.target.closest('#newTagBtn')) {
    addingTag = !addingTag; newTagError = '';
    return renderNewTagRow();
  }
  if (e.target.closest('#newTagAdd')) return commitNewTag($('newTagInput').value);
  const pane = e.target.closest('[data-pane]');
  if (pane) {
    tagPane = pane.dataset.pane;
    renaming = confirming = null; renameError = '';
    return renderTagPop();
  }
  const r = e.target.closest('[data-rename]');
  if (r) { renaming = r.dataset.rename; confirming = null; renameError = ''; return renderTagPop(); }
  const ask = e.target.closest('[data-ask-del]');
  if (ask) { confirming = ask.dataset.askDel; renaming = null; return renderTagPop(); }
  if (e.target.closest('[data-cancel-del]')) { confirming = null; return renderTagPop(); }
  const del = e.target.closest('[data-do-del]');
  if (del) return deleteTag(del.dataset.doDel);

  const b = e.target.closest('[data-tag]');
  if (!b) return;
  const t = b.dataset.tag;
  state.tags.has(t) ? state.tags.delete(t) : state.tags.add(t);
  renderTagPop();
  renderCards();
});

$('tagPop').addEventListener('keydown', e => {
  if (e.target.id === 'newTagInput') {
    if (e.key === 'Enter') { e.preventDefault(); commitNewTag(e.target.value); }
    if (e.key === 'Escape') { e.preventDefault(); addingTag = false; newTagError = ''; renderNewTagRow(); }
    return;
  }
  if (!renaming || !e.target.closest('.tag-manage-edit')) return;
  if (e.key === 'Enter') { e.preventDefault(); renameTag(renaming, e.target.value); }
  if (e.key === 'Escape') { e.preventDefault(); renaming = null; renameError = ''; renderTagPop(); }
});
